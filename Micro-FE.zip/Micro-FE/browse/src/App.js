import "./index.css";

document.getElementById("app").innerHTML = `
<div class="container">
  <div>Name: browse</div>
  <div>Framework: vanilla</div>
  <div>Language: JavaScript</div>
  <div>CSS: Empty CSS</div>
</div>
`;
