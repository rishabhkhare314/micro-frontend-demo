export const JWT_SECRET = process.env.JWT_SECRET || 'secret';
